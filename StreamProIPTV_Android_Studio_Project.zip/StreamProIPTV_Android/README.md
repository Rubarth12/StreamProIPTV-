# StreamPro IPTV — Android Studio starter

An original IPTV-player starter project for Android phones and Android TV devices.

## Included
- M3U playlist URL loading and basic M3U parsing
- Live TV, Movies, Series, Sports Hub and Favorites sections
- Media3/ExoPlayer playback
- Channel search and favorites
- Dark interface designed to scale to phone and TV screens

## Build an APK
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is normally in `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is a starter build, not a finished Televizo replacement.
- Xtream Codes login, EPG/XMLTV, catch-up, multi-playlist management, parental controls,
  external-player selection and polished remote-control navigation are not implemented yet.
- Some providers block playlist downloads or playback, require headers, or use formats/codecs
  not supported by the device. HLS and common Android-supported streams are the best starting point.
- Use only playlists and streams you are authorized to access.
- The app uses its own name and interface; it does not copy Televizo branding or proprietary assets.
