package com.streampro.iptv

import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

data class Channel(val name: String, val group: String, val url: String, val logo: String = "") {
    val category: String get() {
        val g = group.lowercase()
        val n = name.lowercase()
        return when {
            listOf("sport", "sports", "espn", "fox sports", "bein", "dazn").any { it in g || it in n } -> "Sports Hub"
            listOf("movie", "vod", "cinema", "film").any { it in g } -> "Movies"
            listOf("series", "tv show", "episode").any { it in g } -> "Series"
            else -> "Live TV"
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StreamProApp() }
    }
}

@Composable
fun StreamProApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val client = remember { OkHttpClient() }
    var playlistUrl by remember { mutableStateOf("") }
    var channels by remember { mutableStateOf(listOf<Channel>()) }
    var selectedTab by remember { mutableStateOf("Home") }
    var message by remember { mutableStateOf("Add an M3U playlist from your IPTV provider to begin.") }
    var loading by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf<Channel?>(null) }
    var search by remember { mutableStateOf("") }
    val favorites = remember { mutableStateListOf<String>() }
    val player = remember {
        ExoPlayer.Builder(context).build()
    }

    DisposableEffect(Unit) { onDispose { player.release() } }

    val tabs = listOf("Home", "Live TV", "Movies", "Series", "Sports Hub", "Favorites", "Playlist")
    val visible = channels.filter { channel ->
        val tabMatch = when (selectedTab) {
            "Home" -> true
            "Favorites" -> channel.name in favorites
            "Playlist" -> false
            else -> channel.category == selectedTab
        }
        tabMatch && channel.name.contains(search, ignoreCase = true)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF29B6F6),
            background = Color(0xFF07111F),
            surface = Color(0xFF101E30),
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF07111F)).padding(16.dp)
        ) {
            Text("STREAMPRO IPTV", color = Color(0xFF29B6F6), fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Text("Your TV. Your playlists.", color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ScrollableTabRow(selectedTabIndex = tabs.indexOf(selectedTab), edgePadding = 0.dp) {
                    tabs.forEach { tab ->
                        Tab(selected = selectedTab == tab, onClick = { selectedTab = tab },
                            text = { Text(tab, maxLines = 1) })
                    }
                }
            }
            Spacer(Modifier.height(14.dp))

            if (selectedTab == "Playlist") {
                Text("Playlist Manager", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = playlistUrl, onValueChange = { playlistUrl = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("M3U playlist URL") },
                    placeholder = { Text("https://provider.example/playlist.m3u") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        scope.launch {
                            loading = true
                            message = "Loading playlist…"
                            try {
                                val body = withContext(Dispatchers.IO) {
                                    val request = Request.Builder().url(playlistUrl.trim()).build()
                                    client.newCall(request).execute().use { response ->
                                        if (!response.isSuccessful) error("HTTP ${response.code}")
                                        response.body?.string() ?: error("Empty response")
                                    }
                                }
                                channels = parseM3u(body)
                                message = "Loaded ${channels.size} entries."
                            } catch (e: Exception) {
                                message = "Could not load playlist: ${e.message ?: "Check URL and connection"}"
                            } finally { loading = false }
                        }
                    },
                    enabled = !loading && playlistUrl.startsWith("http"),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (loading) "Loading…" else "Load Playlist") }
                Spacer(Modifier.height(10.dp))
                Text(message, color = Color.LightGray)
                Spacer(Modifier.height(8.dp))
                Text("Only use playlists and streams you are authorized to access.", color = Color.Gray, fontSize = 12.sp)
            } else {
                if (current != null) {
                    Text(current!!.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                player = player
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT, 230.dp.value.toInt()
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(230.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { current = null; player.stop() }) { Text("Back to channel list") }
                } else {
                    Text(
                        when (selectedTab) {
                            "Home" -> "Welcome to StreamPro"
                            "Sports Hub" -> "Sports Hub"
                            else -> selectedTab
                        },
                        fontSize = 22.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    if (channels.isNotEmpty()) {
                        OutlinedTextField(
                            value = search, onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Search channels") }, singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        if (selectedTab == "Home") {
                            Text("${channels.size} playlist entries loaded", color = Color.LightGray)
                            Text("Choose Live TV, Movies, Series or Sports Hub above.", color = Color.LightGray)
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(visible) { channel ->
                                Row(
                                    Modifier.fillMaxWidth()
                                        .background(Color(0xFF101E30), RoundedCornerShape(10.dp))
                                        .clickable {
                                            current = channel
                                            player.setMediaItem(MediaItem.fromUri(channel.url))
                                            player.prepare()
                                            player.play()
                                        }
                                        .padding(13.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(channel.name, fontWeight = FontWeight.SemiBold)
                                        Text(channel.group, color = Color.LightGray, fontSize = 12.sp)
                                    }
                                    Text(
                                        if (channel.name in favorites) "★" else "☆",
                                        color = Color(0xFFFFD54F), fontSize = 23.sp,
                                        modifier = Modifier.clickable {
                                            if (channel.name in favorites) favorites.remove(channel.name)
                                            else favorites.add(channel.name)
                                        }.padding(horizontal = 8.dp)
                                    )
                                }
                            }
                        }
                    } else {
                        Text("No playlist loaded yet. Open Playlist to add your M3U URL.", color = Color.LightGray)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { selectedTab = "Playlist" }) { Text("Add Playlist") }
                    }
                }
            }
        }
    }
}

fun parseM3u(text: String): List<Channel> {
    val result = mutableListOf<Channel>()
    var name = "Unknown channel"
    var group = "Other"
    var logo = ""
    text.lineSequence().forEach { raw ->
        val line = raw.trim()
        if (line.startsWith("#EXTINF", ignoreCase = true)) {
            name = line.substringAfterLast(',', "Unknown channel").trim().ifBlank { "Unknown channel" }
            group = Regex("""group-title="([^"]*)"""", RegexOption.IGNORE_CASE)
                .find(line)?.groupValues?.getOrNull(1) ?: "Other"
            logo = Regex("""tvg-logo="([^"]*)"""", RegexOption.IGNORE_CASE)
                .find(line)?.groupValues?.getOrNull(1) ?: ""
        } else if (line.isNotBlank() && !line.startsWith("#") &&
            (line.startsWith("http://") || line.startsWith("https://"))) {
            result.add(Channel(name, group, line, logo))
            name = "Unknown channel"; group = "Other"; logo = ""
        }
    }
    return result
}
